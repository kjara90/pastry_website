let searchForm = document.querySelector('.search-form');

document.querySelector('#search-btn').onclick = () =>{
    searchForm.classList.toggle('active');
    shoppingCart.classList.remove('active');
    loginForm.classList.remove('active');
    navbar.classList.remove('active');
}

let shoppingCart = document.querySelector('.shopping-cart');

document.querySelector('#cart-btn').onclick = () =>{
    shoppingCart.classList.toggle('active');
    searchForm.classList.remove('active');
    loginForm.classList.remove('active');
    navbar.classList.remove('active');
}

let loginForm = document.querySelector('.login-form');

document.querySelector('#login-btn').onclick = () =>{
    loginForm.classList.toggle('active');
    searchForm.classList.remove('active');
    shoppingCart.classList.remove('active');
    navbar.classList.remove('active');
}

let navbar = document.querySelector('.navbar');

document.querySelector('#menu-btn').onclick = () =>{
    navbar.classList.toggle('active');
    searchForm.classList.remove('active');
    shoppingCart.classList.remove('active');
    loginForm.classList.remove('active');
}

window.onscroll = () =>{
    searchForm.classList.remove('active');
    shoppingCart.classList.remove('active');
    loginForm.classList.remove('active');
    navbar.classList.remove('active');
}

var swiper = new Swiper(".product-slider", {
    loop:true,
    spaceBetween: 20,
    autoplay: {
        delay: 7500,
        disableOnInteraction: false,
    },
    centeredSlides: true,
    breakpoints: {
      0: {
        slidesPerView: 1,
      },
      768: {
        slidesPerView: 2,
      },
      1020: {
        slidesPerView: 3,
      },
    },
});

var swiper = new Swiper(".review-slider", {
    loop:true,
    spaceBetween: 20,
    autoplay: {
        delay: 7500,
        disableOnInteraction: false,
    },
    centeredSlides: true,
    breakpoints: {
      0: {
        slidesPerView: 1,
      },
      768: {
        slidesPerView: 2,
      },
      1020: {
        slidesPerView: 3,
      },
    },
});

function validateForm() {
  var emri = document.querySelector('input[name="Name"]').value;
  var email = document.querySelector('input[name="email"]').value;
  var celulari = document.getElementById("celulari").value;
  var zgjedhja = document.getElementById("zgjedhja").value;
  var sasia = document.querySelector('input[type="number"]').value;
  var produktet = getSelectedProduktet();
  var pershkrim = document.querySelector('input[name="pershkrim"]').value;
  var foto = document.getElementById("foto").value;

  // Perform validation checks here
  // ...

  // If form is valid, display the submitted information
  var formIsValid = true; // Replace with actual validation logic
  if (formIsValid) {
    var infoDiv = document.createElement("div");
    infoDiv.innerHTML =
      "<h2>Informacioni i Dërguar:</h2>" +
      "<p><strong>Emri:</strong> " + emri + "</p>" +
      "<p><strong>Email:</strong> " + email + "</p>" +
      "<p><strong>Numri i telefonit:</strong> " + celulari + "</p>" +
      "<p><strong>Zgjedhja:</strong> " + zgjedhja + "</p>" +
      "<p><strong>Sasia:</strong> " + sasia + "</p>" +
      "<p><strong>Produktet:</strong> " + produktet + "</p>" +
      "<p><strong>Pershkrim i produktit:</strong> " + pershkrim + "</p>";
    document.body.appendChild(infoDiv);
  }

  return false; // Prevent form submission
}

function getSelectedProduktet() {
  var produktet = [];
  var checkboxElements = document.querySelectorAll('input[name="produktet"]:checked');
  for (var i = 0; i < checkboxElements.length; i++) {
    produktet.push(checkboxElements[i].value);
  }
  return produktet.join(", ");
}
