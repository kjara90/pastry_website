let searchForm = document.querySelector('.search-form');

document.querySelector('#search-btn').onclick = () =>{
    searchForm.classList.toggle('active');
    shoppingCart.classList.remove('active');
    loginForm.classList.remove('active');
    navbar.classList.remove('active');
}

let shoppingCart = document.querySelector('.shopping-cart');

document.querySelector('#cart-btn').onclick = () =>{
    shoppingCart.classList.toggle('active');
    searchForm.classList.remove('active');
    loginForm.classList.remove('active');
    navbar.classList.remove('active');
}

let loginForm = document.querySelector('.login-form');

document.querySelector('#login-btn').onclick = () =>{
    loginForm.classList.toggle('active');
    searchForm.classList.remove('active');
    shoppingCart.classList.remove('active');
    navbar.classList.remove('active');
}

let navbar = document.querySelector('.navbar');

document.querySelector('#menu-btn').onclick = () =>{
    navbar.classList.toggle('active');
    searchForm.classList.remove('active');
    shoppingCart.classList.remove('active');
    loginForm.classList.remove('active');
}


window.onscroll = () =>{
    searchForm.classList.remove('active');
    shoppingCart.classList.remove('active');
    loginForm.classList.remove('active');
    navbar.classList.remove('active');
}

var swiper = new Swiper(".product-slider", {
    loop:true,
    spaceBetween: 20,
    autoplay: {
        delay: 7500,
        disableOnInteraction: false,
    },
    centeredSlides: true,
    breakpoints: {
      0: {
        slidesPerView: 1,
      },
      768: {
        slidesPerView: 2,
      },
      1020: {
        slidesPerView: 3,
      },
    },
});

var swiper = new Swiper(".review-slider", {
    loop:true,
    spaceBetween: 20,
    autoplay: {
        delay: 7500,
        disableOnInteraction: false,
    },
    centeredSlides: true,
    breakpoints: {
      0: {
        slidesPerView: 1,
      },
      768: {
        slidesPerView: 2,
      },
      1020: {
        slidesPerView: 3,
      },
    },
});

function validateForm() {
  var name = document.getElementById("name").value;
  var email = document.getElementsByName("email")[0].value;
  var phoneNumber = document.getElementById("celulari").value;
  var location = document.getElementById("zgjedhja").value;
  var products = document.getElementsByName("produktet");
  var quantity = document.getElementById("sasia").value;
  var description = document.getElementsByName("mesazh")[0].value;

  var errorMessages = ""; // Variabel ku mbahen mesazhet e gabimit

  // Valido emrin
  if (name.trim() === "") {
    errorMessages += "Ju lutem vendosni emrin tuaj.\n";
  }

  // Validoemail
  if (email.trim() === "") {
    errorMessages += "Ju lutem vendosni email-in tuaj.\n";
  }

  // Valido nr e tel
  var phoneNumberPattern = /^[0-9]{3}-[0-9]{7}$/;
  if (!phoneNumber.match(phoneNumberPattern)) {
    errorMessages += "Ju lutem vendosni numrin e telefonit ne formatin e duhur (XXX-XXXXXXX).\n";
  }

  // Valido vendoshjen
  if (location === "") {
    errorMessages += "Ju lutem zgjidhni vendodhjen.\n";
  }

  // Valido produktet
  var selectedProducts = [];
  for (var i = 0; i < products.length; i++) {
    if (products[i].checked) {
      selectedProducts.push(products[i].value);
    }
  }
  if (selectedProducts.length === 0) {
    errorMessages += "Ju lutem zgjidhni te pakten nje produkt.\n";
  }

  // Valido sasine
  if (quantity.trim() === "" || parseInt(quantity) <= 0) {
    errorMessages += "Ju lutem vendosni sasine e duhur te produkteve.\n";
  }

  // Valido pershkrimin
  if (description.trim() === "") {
    errorMessages += "Ju lutem vendosni pershkrimin e produktit.\n";
  }

  // shfaq mesazh gabimi ose bej submit
  if (errorMessages !== "") {
    alert(errorMessages ) ;
    return false; // ndalon qe forma te behet submit
  } else {
    // forma eshte e validuar
    return true;
  }
}
function validatePassword() {//validojme e passwordin me kete fuksion
  var password = document.getElementById("password1").value;
  var passwordPattern = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;
  if (!password.match(passwordPattern)) {
    alert("Fjalëkalimi duhet të përmbajë të paktën 8 karaktere, të paktën një shkronjë dhe një numër.\n");
  }
}
